browser.browserAction.onClicked.addListener(() => {
    console.log("Audio Channel Splitter Activated");
});
